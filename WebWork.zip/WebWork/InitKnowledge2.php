<?php
$mysqli = new mysqli("localhost", "root", "123456", "Answer");
if(!$mysqli)  {
    echo"database error";
}else{
    //  echo"php env successful";
}
$gotoId=$_GET['QID'];       //上个页面中指定的问题
@session_start();
$_SESSION['QID']=$gotoId;
$_SESSION['StartTime']=time();

$sql = "SELECT * FROM answer.q where QID=".$gotoId;
//$sql = "SELECT * FROM answer.q;";
$result = mysqli_query($mysqli, $sql);
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>学生回答页面</title>
</head>
<body>
    <?php
	while($row = mysqli_fetch_assoc($result)){
	    echo 'QuestionID='.$row['QID'];
	    $QJson=$row['content'];         //获取Json
	    //        var_dump(json_decode($QJson));
	    $Q=json_decode($QJson);
	  ?>
	  <h1>问卷<?php echo $Q->Qname?></h1>
	  
<form action="FinishKnowledge.php" method="get"> 
<?php echo $Q->question1?><br /><br /> 
<label><input name="ANS1" type="radio" value="A" /><?php echo $Q->as1a?> </label> 
<label><input name="ANS1" type="radio" value="B" /><?php echo $Q->as1b?> </label> 
<label><input name="ANS1" type="radio" value="C" /><?php echo $Q->as1c?> </label> 
<label><input name="ANS1" type="radio" value="D" /><?php echo $Q->as1d?> </label> 
 <br /><br /> 


<?php echo $Q->question2?><br /><br /> 
<label><input name="ANS2" type="radio" value="A" /><?php echo $Q->as2a?> </label> 
<label><input name="ANS2" type="radio" value="B" /><?php echo $Q->as2b?> </label> 
<label><input name="ANS2" type="radio" value="C" /><?php echo $Q->as2c?> </label> 
<label><input name="ANS2" type="radio" value="D" /><?php echo $Q->as2d?> </label> 
 <br /><br /> 


<?php echo $Q->question3?><br /><br /> 
<label><input name="ANS3[]" type="checkbox" value="A" /><?php echo $Q->as3a?> </label> 
<label><input name="ANS3[]" type="checkbox" value="B" /><?php echo $Q->as3b?> </label> 
<label><input name="ANS3[]" type="checkbox" value="C" /><?php echo $Q->as3c?> </label> 
<label><input name="ANS3[]" type="checkbox" value="D" /><?php echo $Q->as3d?> </label> 
 <br /><br /> 



<?php echo $Q->question4?><br /><br /> 
<label><input name="ANS4[]" type="checkbox" value="A" /><?php echo $Q->as4a?></label> 
<label><input name="ANS4[]" type="checkbox" value="B" /><?php echo $Q->as4b?></label> 
<label><input name="ANS4[]" type="checkbox" value="C" /><?php echo $Q->as4c?></label> 
<label><input name="ANS4[]" type="checkbox" value="D" /><?php echo $Q->as4d?></label> 
 <br /><br /> 


<?php echo $Q->question5?><br /><br /> 
<label><input name="ANS5" type="radio" value="Y" />正确 </label> 
<label><input name="ANS5" type="radio" value="N" />错误</label> 
 <br /><br />
	
<input type="submit" value="提交">
</form>	  
<?php	  
	}
	?>
</body>
</html>