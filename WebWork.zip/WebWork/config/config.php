<?php
$config = array(
    'host'=>'localhost',
    'user'=>'root',
    'password'=>'123456',
    'charset'=>'utf8',
    'dbName'=>'login'
);


define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PWD','123456');
define('DB_CHARSET','utf8');
define('DB_DBNAME','login');