<?php
$mysqli = new mysqli("localhost", "root", "123456", "Answer");
if(!$mysqli)  {
    echo"database error";
}else{
    //  echo"php env successful";
}

$sql = "SELECT * FROM answer.q;";
$result = mysqli_query($mysqli, $sql);
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>学生主页</title>
</head>
<body>
    <h1>以下为可回答的问卷</h1>
    <?php
	while($row = mysqli_fetch_assoc($result)){
	    echo 'QuestionID='.$row['QID'];
	    $QJson=$row['content'];         //获取Json
	    //        var_dump(json_decode($QJson));
	    $Q=json_decode($QJson);
	  ?>
	  <a href=<?php echo "GotoQuestion.php?QID=".$row['QID']?> ><?php echo $Q->Qname?></a>
<?php	  
	}
	?>
</body>
</html>