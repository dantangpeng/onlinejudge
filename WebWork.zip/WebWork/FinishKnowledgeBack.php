<?php
$mysqli = new mysqli("localhost", "root", "123456", "Answer");
if(!$mysqli)  {
    echo"database error";
}else{
    //  echo"php env successful";
}
session_start();
$gotoId=$_SESSION['QID'];       //上个页面中指定的问题


$sql = "SELECT * FROM answer.q where QID=".$gotoId;

$result = mysqli_query($mysqli, $sql);

$tID="2200";
$tName="测试";

$ANS1=$_GET['ANS1'];
$ANS2=$_GET['ANS2'];
$ANS3=$_GET['ANS3'];
$ANS4=$_GET['ANS4'];
$ANS5=$_GET['ANS5'];

$FinishTime=time();
//计算天数
$timediff = $FinishTime-$_SESSION['StartTime'];
$days = intval($timediff/86400);
//计算小时数
$remain = $timediff%86400;
$hours = intval($remain/3600);
//计算分钟数
$remain = $remain%3600;
$mins = intval($remain/60);
//计算秒数
$secs = $remain%60;


for($T='',$i=0;$i<count($ANS3);$i=$i+1){
    if($i==0){
        $T=$T.$ANS3[$i];
    }
    else{
        $T=$T." ".$ANS3[$i];
    }
    
}
$ANS3=$T;

for($T='',$i=0;$i<count($ANS4);$i=$i+1){
    if($i==0){
        $T=$T.$ANS4[$i];
    }
    else{
        $T=$T." ".$ANS4[$i];
    }
}
$ANS4=$T;

echo "用时:".$mins."分  ".$secs."秒";  

$tTime=$mins.$secs;

while($row = mysqli_fetch_assoc($result)){
    echo 'QuestionID='.$row['QID'];
    $QJson=$row['content'];         //获取Json
    $Q=json_decode($QJson);
    if($ANS1==$Q->Key1){
        echo "第一题回答正确";
    }
    else{
        echo "第一题回答错误，正确答案为".$Q->Key1;
    }
    echo "<br /> ";
    
    if($ANS2==$Q->Key2){
        echo "第二题回答正确";
    }
    else{
        echo "第二题回答错误，正确答案为".$Q->Key2;
    }
    echo "<br /> ";
    
    if($ANS3==$Q->Key3){
        echo "第三题回答正确";
    }
    else{
        echo "第三题回答错误，正确答案为".$Q->Key3;
    }
    echo "<br /> ";
    
    if($ANS4==$Q->Key4){
        echo "第四题回答正确";
    }
    else{
        echo "第四题回答错误，正确答案为".$Q->Key4;
    }
    echo "<br /> ";
    
    
    if($ANS5==$Q->Key5){
        echo "第五题回答正确";
    }
    else{
        echo "第五题回答错误，正确答案为".$Q->Key5;
    }
    
    
	
	echo "<br /> ";echo "<br /> ";echo "<br /> ";echo "<br /> ";
	
	$ToUpdateJson=$row['ansall'];
	$arr=array('Sid'=>$tID,'Sname'=>$tName,'Stime'=>$tTime,'as1'=>$ANS1,'as2'=>$ANS2,'as3'=>$ANS3,'as4'=>$ANS4,'as5'=>$ANS5);
//	$ANSALL=json_encode($arr,JSON_UNESCAPED_UNICODE);
//	$ANSALL = addslashes($ANSALL);
//	echo $ANSALL;
//	echo "<br /> ";echo "<br /> ";echo "<br /> ";echo "<br /> ";
	
	$Q2=json_decode($ToUpdateJson);    //解码ansall
//	echo "Q2等于：".$Q2;
	array_push($Q2->box,$arr);
	$Q2=json_encode($Q2,JSON_UNESCAPED_UNICODE);
//	$Q2 = addslashes($Q2);
?>	
	<button><a href="ShowAnswer.php">查看所有回答</a></button>
	
<?php	
	$mysqli = new mysqli("localhost", "root", "123456", "Answer");
	if(!$mysqli)  {
	    echo"database error";
	}else{
	    //  echo"php env successful";
	}
	
	
	$sql = "update  q  set ansall='".$Q2."'where QID=".$gotoId;
	
	//  $sql = "Insert into answer.q values(\"0002\",null,null);";
	$result = mysqli_query($mysqli, $sql);               
}
?>