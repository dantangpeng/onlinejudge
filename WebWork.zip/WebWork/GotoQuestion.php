<?php
//用于跳转到各种所需的答题界面,如检测题和问卷题
$mysqli = new mysqli("localhost", "root", "123456", "Answer");
if(!$mysqli)  {
    echo"database error";
}else{
    //  echo"php env successful";
}
$gotoId=$_GET['QID'];       //上个页面中指定的问题

$sql = "SELECT * FROM answer.q where QID=".$gotoId;
//$sql = "SELECT * FROM answer.q;";
echo $sql;
$result = mysqli_query($mysqli, $sql);
/*
if(is_resource($result)){

    $row = mysqli_fetch_assoc($result);          //返回集只有一个
    $QJson=$row['content'];         //获取Json
    $Q=json_decode($QJson);
    $flag=$Q->type;
    if($flag=="K"){
    echo "即将进入知识检测类";
}
else{
    echo "即将进入问卷类";
}
}else{
    echo "不存在该试题";
    
}
*/
if (mysqli_num_rows($result) > 0) {
    // 输出数据
    while($row = mysqli_fetch_assoc($result)) {
        $QJson=$row['content'];         //获取Json
        $Q=json_decode($QJson);
        $flag=$Q->type;
        if($flag=="K"){
            echo "即将进入知识检测类";
            @header("location:InitKnowledge.php?QID=".$gotoId);
        }
        else{
            echo "即将进入问卷类";
        }
        $logflag=1;
    }
}

if($logflag==1){
    //            @header("location:LogSucceed.php?name=".$row['bookUserName']);
    //     @header("location:LogSucceed.php");
}
else{
    echo "当前无借阅";
}  

?>
