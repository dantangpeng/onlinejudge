<?php
//展示所有回答的界面
$gotoId=001;
$mysqli = new mysqli("localhost", "root", "123456", "Answer");
if(!$mysqli)  {
    echo"database error";
}else{
    //  echo"php env successful";
}

$sql = "SELECT * FROM answer.q;";

$result = mysqli_query($mysqli, $sql);
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>所有回答记录</title>
</head>
<body>
 
<h1>所有回答记录</h1>
 
<table border="1">
    <tr>
        <td>回答人姓名</td>
        <td>回答所需时间</td>
        <td>第一题答案</td>
        <td>第二题答案</td>
        <td>第三题答案</td>
        <td>第四题答案</td>
        <td>第五题答案</td>
    </tr>
  <?php 
  
  while($row = mysqli_fetch_assoc($result)){ 
      $QJson=$row['ansall'];         //获取Json
      $Q=json_decode($QJson);
      
   //   echo "sdQ为".$Q;
         $arr = $Q->box;
            foreach($arr as $value){
       ?>
    <tr>
        <td><?php  echo $value->Sname; ?></td>
        <td><?php  $Temp=$value->Stime; 
        $TTT=substr($value->Stime,0,1);
        $MMM=substr($value->Stime,-2,2);
        echo $TTT."分".$MMM."秒";
        ?></td>
        <td><?php  echo $value->as1; ?></td>
        <td><?php  echo $value->as2; ?></td>
        <td><?php  echo $value->as3; ?></td>
        <td><?php  echo $value->as4; ?></td>
        <td><?php  echo $value->as5; ?></td>
    </tr>
   <?php } }  ?>
</table>
 
</body>
</html>