<?php
$mysqli = new mysqli("localhost", "root", "123456", "Answer");
if(!$mysqli)  {
    echo"database error";
}else{
    //  echo"php env successful";
}
session_start();
$gotoId=$_SESSION['QID'];       //上个页面中指定的问题


$sql = "SELECT * FROM answer.q where QID=".$gotoId;

$result = mysqli_query($mysqli, $sql);

$tID="2200";
$tName="测试";

$ANS1=$_GET['ANS1'];
$ANS2=$_GET['ANS2'];
$ANS3=$_GET['ANS3'];
$ANS4=$_GET['ANS4'];
$ANS5=$_GET['ANS5'];

$FinishTime=time();
//计算天数
$timediff = $FinishTime-$_SESSION['StartTime'];
$days = intval($timediff/86400);
//计算小时数
$remain = $timediff%86400;
$hours = intval($remain/3600);
//计算分钟数
$remain = $remain%3600;
$mins = intval($remain/60);
//计算秒数
$secs = $remain%60;


for($T='',$i=0;$i<count($ANS3);$i=$i+1){
    if($i==0){
        $T=$T.$ANS3[$i];
    }
    else{
        $T=$T." ".$ANS3[$i];
    }
    
}
$ANS3=$T;

for($T='',$i=0;$i<count($ANS4);$i=$i+1){
    if($i==0){
        $T=$T.$ANS4[$i];
    }
    else{
        $T=$T." ".$ANS4[$i];
    }
}
$ANS4=$T;


$tTime=$mins.$secs;

while($row = mysqli_fetch_assoc($result)){
    $QJson=$row['content'];         //获取Json
    $Q=json_decode($QJson);
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="https://static.pingendo.com/bootstrap/bootstrap-4.1.3.css">
</head>

<body>
  <nav class="navbar navbar-dark bg-primary">
    <div class="container d-flex justify-content-center"> <a class="navbar-brand" href="#">
        <i class="fa d-inline fa-lg fa-circle-o"></i>
        <b>回答结果</b>
      </a> </div>
  </nav>
  <div class="py-1">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="list-group">
            <a href="#" class="list-group-item list-group-item-action active"> <?php echo "用时:".$mins."分  ".$secs."秒";  ?></a>
            <a href="#" class="list-group-item list-group-item-action"><?php  if($ANS1==$Q->Key1){
        echo "第一题回答正确";
    }
    else{
        echo "第一题回答错误，正确答案为".$Q->Key1;
    }?></a>
            <a href="#" class="list-group-item list-group-item-action"><?php if($ANS2==$Q->Key2){
        echo "第二题回答正确";
    }
    else{
        echo "第二题回答错误，正确答案为".$Q->Key2;
    }?></a>
            <a href="#" class="list-group-item list-group-item-action"><?php  if($ANS3==$Q->Key3){
        echo "第三题回答正确";
    }
    else{
        echo "第三题回答错误，正确答案为".$Q->Key3;
    }?></a>
            <a href="#" class="list-group-item list-group-item-action disabled"><?php  if($ANS4==$Q->Key4){
        echo "第四题回答正确";
    }
    else{
        echo "第四题回答错误，正确答案为".$Q->Key4;
    }?></a>
            <li class="list-group-item d-flex justify-content-between align-items-start"><?php  if($ANS5==$Q->Key5){
        echo "第五题回答正确";
    }
    else{
        echo "第五题回答错误，正确答案为".$Q->Key5;
    }
    ?></li>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php echo "<br /> ";echo "<br /> ";echo "<br /> ";echo "<br /> ";
	
	$ToUpdateJson=$row['ansall'];
	$arr=array('Sid'=>$tID,'Sname'=>$tName,'Stime'=>$tTime,'as1'=>$ANS1,'as2'=>$ANS2,'as3'=>$ANS3,'as4'=>$ANS4,'as5'=>$ANS5);
//	$ANSALL=json_encode($arr,JSON_UNESCAPED_UNICODE);
//	$ANSALL = addslashes($ANSALL);
//	echo $ANSALL;
//	echo "<br /> ";echo "<br /> ";echo "<br /> ";echo "<br /> ";
	
	$Q2=json_decode($ToUpdateJson);    //解码ansall
//	echo "Q2等于：".$Q2;
	array_push($Q2->box,$arr);
	$Q2=json_encode($Q2,JSON_UNESCAPED_UNICODE);
//	$Q2 = addslashes($Q2);
?>
  
  
  
  <div class="py-0">
    <div class="container">
      <div class="row">
        <div class="col-md-12"><a class="btn text-white btn-block" href="ShowAnswer.php" style="background:#e52d27" target="_blank"><i class="fa fa-youtube fa-fw fa-1x py-1"></i>查看所有回答情况</a></div>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  
</body>

</html>

<?php	
	$mysqli = new mysqli("localhost", "root", "123456", "Answer");
	if(!$mysqli)  {
	    echo"database error";
	}else{
	    //  echo"php env successful";
	}
	
	
	$sql = "update  q  set ansall='".$Q2."'where QID=".$gotoId;
	
	//  $sql = "Insert into answer.q values(\"0002\",null,null);";
	$result = mysqli_query($mysqli, $sql);               
}
?>